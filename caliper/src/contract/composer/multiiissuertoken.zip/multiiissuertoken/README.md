cnpm i



sudo ./installer/appinstall.sh



composer archive create --sourceType dir --sourceName . -a dist/token-network.bna